#include<stdio.h>

int main() {
    float weight;
    float moon = 0.17;
    float moonweight;

    printf("weight = ");
    scanf_s("%f",  & weight);
    moonweight = weight * moon;
    printf("The weight on the surface of the ”moon” = %3.2f Kg", moonweight);
    return 0;
}