#include<stdio.h>

int main() {

    float kai, km, speed;
    float time;
    int i;

    printf("計算する回数を入力してください：");
    scanf_s("%f", & kai);

    for(i = 1; i<=kai; i++) {
        printf("距離(km)を入力してください：");
        scanf_s("%f", & km);
        printf("平均速度(km/h)を入力してください：");
        scanf_s("%f", & speed);
        time = km / speed;
        printf("所要時間は %3.1f 時間です。\n", time);
    }

    return 0;

}