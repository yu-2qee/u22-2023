#include<stdio.h>

int main() {
    int i;
    int tab=0,newline=0,at=0;

    printf("入力してください。");

    while(1){
        i = getchar();

        switch(i) {
            case '\t':
                tab++;
                break;

            case '\n':
                newline++;
                break;

            case '@' :
                at++;
                break;

            case 'q':
                printf("タブ:%d回\n", tab);
                printf("改行:%d回\n", newline);
                printf("@   :%d回\n", at);
                return 0;

            default:
                break;
        }
    }
    return 0;
}