/*オペランド例文1*/
#include<stdio.h>

int main() {
    int i;

    printf("「i = 20」の式の値は%dです\n", i = 20);
    return 0;
}