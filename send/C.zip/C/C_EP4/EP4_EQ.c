/*等号例文1*/
#include<stdio.h>

int main() {
    int a = 10;

    printf("a の値は10です\n");
    printf("a == 10の値は「%d」です\n",a == 10);
    printf("a == 20の値は「%d」です\n",a == 20);
    printf("a != 10の値は「%d」です\n",a != 10);
    printf("a != 20の値は「%d」です\n",a != 20);
    
    return 0;
}