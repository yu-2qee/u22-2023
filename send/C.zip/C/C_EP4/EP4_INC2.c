/*インクリメント例文2*/
#include<stdio.h>

int main() {
    int a, b;

    /*書き方注意*/
    /*a = (a = 10)であり a は 10 が代入される*/
    a = b = 10;

    printf("a = %d\n",a++);
    b = b +1;
    printf("b = %d\n",b);

    return 0;
}