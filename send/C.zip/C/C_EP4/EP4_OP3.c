/*オペランド例文3*/
#include<stdio.h>

int main() {
    int a;
    double b;

    a = 10;
    b = 2.35;

    printf("%d + %f = %f\n", a, b, a + b);

    return 0;
}