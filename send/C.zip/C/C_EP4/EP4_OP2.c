/*オペランド例文2*/
#include<stdio.h>

int main() {
    int a = 10, b = 3;
    double c;

    c = a/ b;

    printf("%d ÷ %d = %f\n", a, b, c);
    return 0;
}