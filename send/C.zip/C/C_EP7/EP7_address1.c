/*アドレス例文*/
#include<stdio.h>

int main() {
    char c;
    int i;
    double d, e;

    printf("変数cのアドレスは %p です\n", &c);
    printf("変数iのアドレスは %p です\n", &i);
    printf("変数dのアドレスは %p です\n", &d);
    printf("変数eのアドレスは %p です\n", &e);

    return 0;
}