#include<stdio.h>

void swap(int *x,int *y);

int main() {
    int a, b;

    a = 10;
    b = 20;

    swap(&a, &b);

    printf("a = %d\n",a);
    printf("b = %d\n",b);

    return 0;

}

void swap(int *x,int *y) {
    int z;

    z = *x;
    *x = *y;
    *y = z;

    return;
}