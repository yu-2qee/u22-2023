#include<stdio.h>

int main() {
    int data[3][5] ={{1,2,3,4,5},{6,7,8,9,10},{99,98,97,96,95}};
    int sum=0,i,j;
    int *p;

    p = data;

    for(i=0;i<3;i++) {
        for(j=0;j<5;j++){
            sum = sum +*(p+j);
        }
    }

    printf("２次元配列合計：%d",sum);
    return 0;
}