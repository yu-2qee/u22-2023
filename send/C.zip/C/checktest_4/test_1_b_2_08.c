#include <stdio.h>

int main() {
    int year, month, date;
    char phone[20];
    char *p;

    p = phone;

    printf("生まれ年を入力してください(西暦)：");
    scanf_s("%d", &year);

    printf("生まれ月を入力してください。：");
    scanf_s("%d", &month);

    printf("生まれた日を入力してください。：");
    scanf_s("%d", &date);

    printf("電話番号を入力してください。：");
    scanf_s("%s", phone, sizeof(phone));
    printf("あなたの生年月日は %02d/%02d/%04d です。\n", month, date, year);
    printf("電話番号は %s です。\n", p);

    return 0;
}














/*#include<stdio.h>

int main() {
    int year,month,date;
    char phone[20][20];
    char *p;

    p = phone;

    printf("生まれ年を入力してください(西暦)：");
    scanf_s("%d",& year);
    printf("生まれ月を入力してください。：");
    scanf_s("%d",& month);
    printf("生まれた日を入力してください。：");
    scanf_s("%d",& date);
    printf("電話番号を入力してください。：");
    scanf_s("%c",& p);

    printf("あなたの生年月日は %2d/%2d/%4d です。\n",month,date,year);
    printf("電話番号は %c です。\n",p);
    return 0;
}*/