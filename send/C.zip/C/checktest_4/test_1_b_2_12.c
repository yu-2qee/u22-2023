#include<stdio.h>

int main() {
    int nin,ten,yuu=0,ryou=0,ka=0,huka=0,i;

    do {
        printf("評価する人数の入力：");
        scanf_s("%d", & nin);
        if(nin > 100) {
            printf("100以下を入力してください。\n");
        }
    }while(nin >= 101);

    for(i=1;i<=nin;i++) {
        do {
            printf("%d人目 得点：",i);
            scanf_s("%d", & ten);
            if(ten >= 101) {
                printf("100点以下を入力してください。\n");
            }
        }while(ten >= 101);
        if(ten >= 90) {
            yuu++;
        }
        else if(ten >= 70) {
            ryou++;
        }
        else if(ten >= 50) {
            ka++;
        }
        else {
            huka++;
        }
    }
    printf(" 優%d人\n 良%d人\n 可%d人\n 不可%d人",yuu,ryou,ka,huka);
    return 0;
}