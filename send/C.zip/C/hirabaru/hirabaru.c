#include <stdio.h>
#include <stdlib.h>
#include <time.h>
 
// サイコロを振る
void rollDice(int dice[3]) {
    for (int i = 0; i < 3; i++) {
        dice[i] = rand() % 6 + 1;
    }
}  
 
// 出目の表示
void printDice(int dice[3]) {
    printf("出目: [%d] [%d] [%d]\n", dice[0], dice[1], dice[2]);
}
 
// ゾロ目判定
int isZorome(int dice[3]) {
    return (dice[0] == dice[1] && dice[1] == dice[2]);
}
 
// 1・2・3（負け）の判定
int isStraight(int dice[3]) {
    int a = dice[0], b = dice[1], c = dice[2];
    int sum = a + b + c;
    return (sum == 6 && a != b && b != c && a != c);
}
 
// 4・5・6（勝ち）の判定
int is456(int dice[3]) {
    int a = dice[0], b = dice[1], c = dice[2];
    int sum = a + b + c;
    return (sum == 15 && a != b && b != c && a != c);
}
 
// ポイント（ペア＋1個）の取得
int getPoint(int dice[3]) {
    if (dice[0] == dice[1]) return dice[2];
    if (dice[0] == dice[2]) return dice[1];
    if (dice[1] == dice[2]) return dice[0];
    return 0;
}
 
// 任意のキーで進む（Enterだけではなく）
void waitForNext() {
    printf("\n次に進むには Enter キーを押してください...");
    while (getchar() != '\n');
}
 
// ゲームの実行
void playChinchiro() {
    int dice[3];
    int tries = 3;
 
    while (tries--) {
        printf("\nサイコロを振ります...\n");
        rollDice(dice);
        printDice(dice);
 
        if (isZorome(dice)) {
            printf("嵐！勝ち！\n");
            break;
        } else if (isStraight(dice)) {
            printf("1・2・3！負け！\n");
            break;
        } else if (is456(dice)) {
            printf("4・5・6！勝ち！\n");
            break;
        } else {
            int point = getPoint(dice);
            if (point > 0) {
                printf("出目は %d です。\n", point);
                break;
            } else {
                printf("役なし。もう一度！\n");
            }
        }
        waitForNext();  // キー入力待ち
    }
 
    if (tries < 0) {
        printf("3回振っても役が出ませんでした。負け！\n");
    }
}
 
int main() {
    srand((unsigned int)time(NULL));
 
    int choice;
 
    printf("=== チンチロリン ゲーム ===\n");
 
    while (1) {
        playChinchiro();
 
        // 入力バッファクリア
        int c;
        while ((c = getchar()) != '\n' && c != EOF);
 
        printf("\nもう一度プレイしますか？\n");
        printf("1: はい  0: 終了\n");
        printf("選択: ");
        if (scanf_s("%d", &choice) != 1 || (choice != 0 && choice != 1)) {
            printf("無効な入力です。ゲームを終了します。\n");
            break;
        }
 
        // 入力バッファクリア
        while ((c = getchar()) != '\n' && c != EOF);
 
        if (choice == 0) {
            printf("ゲームを終了します。\n");
            break;
        }
    }
 
    return 0;
}
 