/*スキャン例文1*/
#include<stdio.h>

int main() {
    int seisu;

    printf("整数値を入力してください----");
    scanf_s("%d", & seisu);
    printf("あなたの入力した数値は %d ですね\n",seisu);

    return 0;
}