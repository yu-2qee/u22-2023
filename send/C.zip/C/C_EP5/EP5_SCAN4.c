/*スキャン例文4*/

#include<stdio.h>

int main() {
    int age;
    int is_seito;

    printf("この度は「猫でもランド」に\n"
            "ご来園ありがとうございます。\n");
    printf("------------------------------------\n");
    printf("年齢を入力してください---");
    scanf_s("%d", & age);
    printf("「猫でも学園」の生徒ですか？(Yes:1 No:0)----");
    scanf_s("%d", & is_seito);
    if(age < 6 || is_seito ==1) {
        printf("入園料は無料です\n");
    }
    else {
        printf("入園料は1000円です。\n");
    }

    printf("------------------------------------\n");
    printf("では、ごゆっくりお楽しみください。\n");
    return 0;
}