/*条件演算例文*/
#include<stdio.h>

int main() {
    (3 > 5) ? printf("3 は 5 より大きい\n") :
              printf("3 は 5 より大きくない\n");
    
    return 0;

}