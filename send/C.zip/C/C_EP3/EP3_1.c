/*例文1*/
#include<stdio.h>

int main() {
    int a, b, c;

    a = 10;
    b = 15;

    c = a + b;

    printf("%dたす%dは%dです", a, b, c);

    return 0; 
}
