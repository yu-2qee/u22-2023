/*例文2*/
#include<stdio.h>

int main() {
    int a,b;

    a = 10;
    b = 15;

    printf("%dたす%dは%dです", a, b, a+b);

    return 0; 
}