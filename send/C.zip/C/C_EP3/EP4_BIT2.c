/*ビット例文2*/

#include<stdio.h>

int main() {
    int a = 10;

    printf("a = %08X\n~a = %08X\n", a, ~a);

    return 0;
}