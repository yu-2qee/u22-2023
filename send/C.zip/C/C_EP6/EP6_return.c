/*再起呼び出し例文*/

#include<stdio.h>

int kaijou();

int main() {

    int i;
    for(i = 0; i < 11; i++) {
        printf("%d! = %d\n", i, kaijou(i));

        return 0;
    }
    
}

int kaijou(int n) {
    if(n == 0)
        return 1;
    else 
        return n * kaijou(n - 1);
}

