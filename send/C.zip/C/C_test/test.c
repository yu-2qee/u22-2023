#include<stdio.h>

int main() {

    printf("Hello World!\n");
    
}

int gou() {
    int a;
    int b;
    int gou;

    a = 10;
    b = 20;
    gou = 0;

    gou =a + b;
    printf(gou+"\n");
    return 0;
}


