/*演習問題6*/

#include<stdio.h>

int main() {

    int youbi, zikan;

    printf(">0= 日曜、 1= 月曜、 2=火曜、3= 水曜、4= 木曜、5= 金曜、6= 土曜\n");
    printf(">0= 午前、1= 午後、2= 夜間\n");

    printf("何曜日ですか？(数値で入力してください)---");
    scanf_s("%d", & youbi);
    printf("どの時間帯ですか？(数値で入力してください)---");
    scanf_s("%d", & zikan);

    /*入力確認*/
    if(youbi > 6) {
        printf("指定された数値内で入力してください。\n");
    }

    if(zikan > 3) {
        printf("指定された数値内で入力してください。\n");
    }


    /*日曜日*/
    if(youbi == 0) {
        printf("日曜日は、終日休診日です。");
    }

    /*月曜日*/
    if(youbi == 1) {
        if(zikan == 0) {
            printf("月曜日の午前 ですね。病院は開いています。");
        }
        else if(zikan == 1) {
            printf("月曜日の午後 ですね。病院は開いています。");
        }
        if(zikan == 2) {
            printf("月曜日の夜間 ですね。病院は開いています。");
        }
    }

    /*火曜日*/
    if(youbi == 2) {
        if(zikan == 0) {
            printf("火曜日の午前 ですね。病院は休診です。");
        }
        else if(zikan == 1) {
            printf("火曜日の午後 ですね。病院は開いています。");
        }
        if(zikan == 2) {
            printf("火曜日の夜間 ですね。病院は開いています。");
        }
    }

    /*水曜日*/
    if(youbi == 3) {
        if(zikan == 0) {
            printf("水曜日の午前 ですね。病院は開いています。");
        }
        else if(zikan == 1) {
            printf("水曜日の午後 ですね。病院は開いています。");
        }
        if(zikan == 2) {
            printf("水曜日の夜間 ですね。病院は休診です。");
        }
    }

    /*木曜日*/
    if(youbi == 4) {
        if(zikan == 0) {
            printf("木曜日の午前 ですね。病院は開いています。");
        }
        else if(zikan == 1) {
            printf("木曜日の午後 ですね。病院は開いています。");
        }
        if(zikan == 2) {
            printf("木曜日の夜間 ですね。病院は開いています。");
        }
    }

    /*金曜日*/
    if(youbi == 5) {
        if(zikan == 0) {
            printf("金曜日の午前 ですね。病院は休診です。");
        }
        else if(zikan == 1) {
            printf("金曜日の午後 ですね。病院は開いています。");
        }
        if(zikan == 2) {
            printf("金曜日の夜間 ですね。病院は開いています。");
        }
    }

    /*土曜日*/
    if(youbi == 6) {
        if(zikan == 0) {
            printf("土曜日の午前 ですね。病院は開いています。");
        }
        else if(zikan == 1) {
            printf("土曜日の午後 ですね。病院は休診です。");
        }
        if(zikan == 2) {
            printf("土曜日の夜間 ですね。病院は休診です。");
        }
    }
}

