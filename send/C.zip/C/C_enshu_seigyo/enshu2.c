/*演習問題２*/

#include<stdio.h>

int main() {
    int x, y;
    printf("xの値は？-----");
    scanf_s("%d", & x);
    printf("yの値は？-----");
    scanf_s("%d", & y);
    if(y < x) {
        printf("xはyより大きい");
    }
    else if(x < y) {
        printf("yはxより大きい");        
    }
}