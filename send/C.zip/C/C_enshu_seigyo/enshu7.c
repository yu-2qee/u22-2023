/*演習問題7*/

#include<stdio.h>

int main() {
    int i, tuki;

    printf("入力した月から年末までの祝日を表示します。\n");
    printf("何月からですか？---");
    scanf_s("%d", & tuki);

    for(i = tuki; i <= 12; i++){
        switch (i) {
            case 1:/*1月*/
                printf("１月：元日、成人の日\n");
                break;

            case 2:/*2月*/
               printf("２月：建国記念の日\n");
               break;

            case 3:/*3月*/
                printf("３月：春分の日\n");
                break;

            case 4:/*4月*/
                printf("４月：昭和の日\n");
                break;

            case 5:/*5月*/
                printf("５月：憲法記念日、みどりの日、こどもの日\n");
                break;

            case 7:/*7月*/
                printf("７月：海の日\n");
                break;

            case 9:/*9月*/
                printf("９月：敬老の日、秋分の日\n");
                break;

            case 10:/*10月*/
                printf("１０月：体育の日\n");
                break;

            case 11:/*11月*/
                printf("１１月：文化の日、勤労感謝の日\n");
                break;

            case 12:/*12月*/
                printf("１２月：天皇誕生日\n");
                break;
                
            default:
                break;
        }
    }
}