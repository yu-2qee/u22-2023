/*演習問題5*/

#include<stdio.h>

int main() {

    int tensuu;

    printf("あなたの点数は？(0 ～ 100 点)---");
    scanf_s("%d", & tensuu);

    /*ケース1*/
    if(tensuu >= 0 && tensuu <= 100) {
        if(tensuu >= 60) {
            printf("合格\n");
        }
        else {
            printf("不合格\n");
        }
    }

    /*ケース2*/
    if(tensuu >= 0 && tensuu <= 100) {
        if(tensuu >= 80) {
            printf("たいへんよくできました。\n");
        }
        if(tensuu >= 60){
            printf("よくできました。\n");
        }
        else {
            printf("ざんねんでした。\n");
        }
    }

    /*ケース3*/
    if(tensuu >= 0 && tensuu <= 100) {
        if(tensuu >= 80) {
            printf("優\n");
        }
        else if(tensuu >= 70) {
            printf("良\n");
        }
        else if(tensuu >= 60) {
            printf("可\n");
        }
        else {
            printf("不可\n");
        }
    }

    printf("終了");
    return 0;
}