/*演習問題３*/

#include<stdio.h>

int main() {
    int seisuu1, seisuu2;
    printf("一つ目の整数は？-----");
    scanf_s("%d", & seisuu1);

    printf("二つ目の整数は？-----");
    scanf_s("%d", & seisuu2);

    if(seisuu2 < seisuu1) {
        printf("大きい整数は%d", seisuu1);
    }
    else if(seisuu1 < seisuu2) {
        printf("大きい整数は %d", seisuu2); 
    }
}