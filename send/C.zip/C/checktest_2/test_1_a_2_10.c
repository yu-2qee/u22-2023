#include<stdio.h>

int fact();
int main() {
    int i,j;
    printf("階乗を計算します。\n");
    printf("数値を入力してください---");
    scanf_s("%d", & i);
    j = fact(i);
    printf("%d の階乗は %d です。", i, j);
    return 0;
}

int fact(int i) {
    int y,x;
    x = i - 1;
    for(y=x;y>=1;y--) {
        i *= y;
    }
    return i;
}