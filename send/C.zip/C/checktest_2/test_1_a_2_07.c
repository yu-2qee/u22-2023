#include<stdio.h>

int main() {
    int i, j, x, y, kai;

    while(1) {
        kai = 0;
        printf("正の整数を入力してください：");
        scanf_s("%d", & i);
        if(i == 0) {
            break;
        }
        for(x=1;x<=i;x++) {
            y = i % x;
            if(y == 0) {
                kai += 1;
            }
        }
        if(kai == 2) {
            printf("その数は素数です。\n");
        }
        else {
            printf("その数は素数ではありません。\n");
        }
    }
    return 0;
}