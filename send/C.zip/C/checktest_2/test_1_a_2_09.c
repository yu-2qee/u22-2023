#include<stdio.h>

int main() {

    int i, ans, you;
    ans = rand() % 100 + 1;
    for(i=0; i<=9; i++) {
        printf("数値を入力してください---");
        scanf_s("%d", & you);
        if(ans < you) {
            printf("%d より小さいです。\n", you);
        }
        else if(ans > you){
            printf("%d より大きいです。\n", you);
        }
        else if(ans == you){
            printf("正解です！");
            return 0;
        }
    }
    printf("失敗...");
    return 0;
}