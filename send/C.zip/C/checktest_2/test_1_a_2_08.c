#include<stdio.h>

int main() {
    float pond, m, feet, ons;
    int select, i;

    feet = m * 3.28;
    ons = pond * 16;

    do {
        printf("入力する形式を選択してください。(0=メートル、1=フィート)---");
        scanf_s("%d", & i);
        if(i==0){
            printf("長さを入力(m)---");
            scanf_s("%f", & m);
        }
        else if(i==1){
            printf("長さを入力(feet)---");
            scanf_s("%f", & feet);
        }
    }while(m ==0 || feet == 0);

    do {
        printf("入力する形式を選択してください。(0=ポンド、1=オンス)");
        scanf_s("%d", & i);
        if(i==0){
            printf("重さを入力(ポンド)---");
            scanf_s("%f", & pond);
        }
        else if(i==1){
            printf("重さを入力(オンス)---");
            scanf_s("%f", & ons);
        }
    }while(pond ==0 || ons == 0);

    while(1){
        printf("変換\n");
        printf("1.フィートからメートルへ\n");
        printf("2.メートルからフィートへ\n");
        printf("3.オンスからポンドへ\n");
        printf("4.ポンドからオンスへ\n");
        printf("5.終了\n");
        printf("番号を選んで入力してください：");
        scanf_s("%d", & select);
        switch (select)
        {
        case 1:
            printf("%10.5f フィートは %10.5f メートルです。\n",feet, feet/3.28);
            m = feet/3.28;
            break;
        case 2:
            printf("%10.5f メートルは %10.5f フィートです。\n",m, m*3.28);
            m = m*3.28;
            break;
        case 3:
            printf("%10.5f オンスは %10.5f ポンドです。\n",ons,ons/16);
            pond = ons /16;
            break;
        case 4:
            printf("%10.5f ポンドは %10.5f オンスです。\n",pond,pond*16);
            ons = pond*16;
            break;
        case 5:
            printf("終了します。\n");
            return 0;
        default:
            break;
        }
    }
    return 0;
}