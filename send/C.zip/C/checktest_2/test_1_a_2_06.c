#include<stdio.h>

int main() {
    int heya,nagasa,haba,gou,menseki;

    printf("部屋の数を入力してください：");
    scanf_s("%d", & heya);

    for(int i=1; i<=heya; i++) {
        printf("長さを入力してください：");
        scanf_s("%d", & nagasa);
        printf("部屋の幅を入力してください：");
        scanf_s("%d", & haba); 
        menseki = nagasa * haba;
        gou += menseki;
    }
    printf("総床面積：%d\n", gou);
    return 0;
}