/*関数演習問題3-1*/

#include<stdio.h>

int hikaku();

int main() {

    int x, y, z;
    printf("入力された値を比較して大きい方の値を出力します。\n");
    printf("一つ目の値を入力してください---");
    scanf_s("%d", & x);
    printf("二つ目の値を入力してください---");
    scanf_s("%d", & y);

    z = hikaku(x, y);
    if(z == NULL) {
        printf("二つの値は同じです。\n");
    }
    else {
    printf("大きいほうの値は %d です。\n",z);
    }
}

int hikaku(int x, int y) {
    int a;
    if(x < y) {
        return y;
    }
    else if( y < x) {
        return x;
    }
    else {
        a = NULL;
        return a;
    }
}