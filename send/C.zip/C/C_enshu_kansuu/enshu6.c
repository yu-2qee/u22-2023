/*関数演習問題6*/

#include<stdio.h>

int henkan(char i) {
    if(i >= 'a' && i <= 'z') {
        i = i - 32;
    }
    return i;
}

int main() {
    char i, j;

    printf("入力された一文字で小文字のアルファベットを大文字に変換します\n");
    printf("一文字の小文字を入力してください---");
    scanf_s("%c", & i);
    j = henkan(i);
    printf("変換結果：%c", j);
    return 0;
}

