/*関数演習問題*/

#include<stdio.h>

int jousuu();

int main() {
    int i, a;

    printf("入力した値を二乗した値を出力します。\n");
    printf("二乗する数を入力してください---");
    scanf_s("%d", & i);

    a = jousuu(i);
    printf("%d を二乗した数は %d", i, a);
    return 0;
}

int jousuu(int i) {
    int w;
    w = i * i;
    return w;
}