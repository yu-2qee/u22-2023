/*関数演習問題3-2*/

#include<stdio.h>

int hikaku();

int main() {

    int x, y, z, a;
    printf("入力された値を比較して大きい値を出力します。\n");
    printf("一つ目の値を入力してください---");
    scanf_s("%d", & x);
    printf("二つ目の値を入力してください---");
    scanf_s("%d", & y);
    printf("三つ目の値を入力してください---");
    scanf_s("%d", & z);


    a = hikaku(x, y, z);
    if(a == NULL) {
        printf("三つの値は同じです。\n");
    }
    else {
        printf("三つの値で最も大きいのは %d です。\n",a);
        return 0;
    }
}

int hikaku(int x, int y, int z) {
    int a;

    if(x == y && x == z) {
        a = NULL;
        return a;
    }

    if(x > y) {
        if(x > z) {
            return x;
        }
        else {
            return z;
        }
    }
    else if(x < y) {
        if(y >= z) {
            return y;
        }
        else {
            return z;
        }
    }
}