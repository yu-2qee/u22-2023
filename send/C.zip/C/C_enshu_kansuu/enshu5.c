/*関数演習問題5*/

#include<stdio.h>

int kuku();

int main() {
    int dan;
    printf("入力された段の九九を出力します。\n");
    printf("何の段ですか---");
    scanf_s("%d", & dan);
    
    if(dan >= 10 || dan <=0) {
        printf("10以上、または1未満の段はは出力できないため、終了します。\n");
        return 0;
    }

    kuku(dan);
    return 0;
}

int kuku(int i) {
    int j,a;

    for(j = 1; j <= 9; j++) {
        a = i * j;
        if(j == 1){
            printf("%dの段 %d ",i, a);
        }
        else {
            printf("%d ",a);
        }
    }
}