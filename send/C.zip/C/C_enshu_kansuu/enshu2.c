/*関数演習問題2*/

#include<stdio.h>

int heikin();
int main() {
    int a, b, c;

    printf("入力した二つの値の平均を出力します。\n");
    printf("一つ目の値を入力してください---");
    scanf_s("%d", & a);
    printf("二つ目の値を入力してください---");
    scanf_s("%d", & b);

    c =heikin(a, b);
    printf("%d と %d の平均は %d です。", a, b, c);
    return 0;
}

int heikin(int a, int b) {
    int h;
    h = (a + b) / 2;
    return h;
}