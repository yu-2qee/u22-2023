/*関数演習問題4*/

#include<stdio.h>

int sankaku();

int main() {
    int a, u;

    for(u = 0; u <= 2; u++) {
        printf("入力した値 × 段の三角形を出力します。\n");
        printf("数値を入力---");
        scanf_s("%d", & a);

        a =sankaku(a);
    }
    return 0;
}

sankaku(int a) {
    int i, j;
    for(i = 1; i <= a; i++){
        for(j = 1; j <= i; j++) {
            printf("$");
        }
        printf("\n");
    }
    return 0;
}