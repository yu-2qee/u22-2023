/*構造体演習 webサイト*/

struct student_tag {
    int year;
    int clas;
    int number;
    char name[64];
    double stature;
    double weight;
};

typedef struct student_tag student;
