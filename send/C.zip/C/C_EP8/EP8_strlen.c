/*文字列比較2*/

#include<stdio.h>
#include<string.h>

int main() {

    char str[32];
    size_t len;

    printf("文字列を入力してください---");
    scanf_s("%s",str);

    len = strlen(str);

    printf("%s の長さは%d です\n",str,len);

    return 0;

}