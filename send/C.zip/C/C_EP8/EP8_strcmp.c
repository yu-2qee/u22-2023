/*文字列比較1*/

#include<stdio.h>
#include<string.h>

int main() {
    char str1[32], str2[32];
    int cmp;

    printf("str1を入力してください-----");
    scanf_s("%s", str1);
    printf("str2を入力してください-----");
    scanf_s("%s", str2);

    cmp = strcmp(str1, str2);
    if(cmp < 0)
        printf("%s は、%s より前にあります",str1, str2);
    else if(cmp > 0)
        printf("%s は、%s より後ろにあります",str1, str2);
    else
        printf("%s と %s は同じ文字列です",str1, str2);

    return 0;
}