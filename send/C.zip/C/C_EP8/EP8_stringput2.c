/*文字列配列例文2*/
#include<stdio.h>

int main() {
    char str[64];

    printf("文字列を入力してください---");
    fgets(str, sizeof(str), stdin); /*入力の読み取り*/
    str[strlen(str) -1] = '\0';

    printf("入力した文字列は「%s」ですね\n", str);
    return 0;
}