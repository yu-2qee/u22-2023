/*文字列入力例文*/

#include<stdio.h>

int main() {
    char str[32];

    printf("文字列を入力してください---");
    scanf_s("%s", str);
    printf("あなたの入力した文字列は「%s」ですね\n", str);

    return 0;
}