/*文字列連結例文*/
#include<stdio.h>
#include<string.h>

int main() {
    char name[64], sama[] = "様";

    printf("お名前を入力してください。---");
    fgets(name, sizeof(name) - sizeof(sama), stdin);
    if(strchr(name, '\n'))
        name[strlen(name) - 1] = '\0';

    printf("%s ですね。お待ちしておりました\n",strcat(name, sama));

        return 0;
}