#include<stdio.h>

int main() {
    float arr[5];
    float gou,hei,sho=0;
    int i,kai=0;

    printf("値を入力してください。\n");
    for(i=1;i<=5;i++){
        printf("%d番：",i);
        scanf_s("%f", & arr[i]);
        gou += arr[i];
        kai++;
        if(sho==0) {
            sho = arr[i];
        }
        else if (arr[i]<sho) {
            sho = arr[i];
        }
    }
    hei=gou / kai;
    printf("合計値：%.0f\n",gou);
    printf("最小値：%.0f\n",sho);
    printf("平均値：%.2f\n",hei);
    return 0;
}