#include<stdio.h>

int main() {
    char cs[3][100];

    for(int i=0;i<3;i++) {
        printf("cs[%d]：",i);
        scanf_s("%99s", & cs[i]);
    }

    for(int j=0;j<3;j++) {
        printf("cs[%d]＝%s\n",j,cs[j]);
    }
    return 0;
}