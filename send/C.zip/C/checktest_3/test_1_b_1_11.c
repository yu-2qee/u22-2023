#include<stdio.h>

int main(){
    int data[5];
    int i,temp;
    int j=0,x=0,dai=0,sho=0;

    for(i=0;i<=4;i++) {
        printf("data[%d]：",i);
        scanf_s("%d", & data[i]);
    }

    for(j = 0; j < 4; j++) {
        for(x = 0; x < 4 - j; x++) {
            if(data[x] > data[x + 1]) {
                temp = data[x];
                data[x] = data[x + 1];
                data[x + 1] = temp;
            }
        }
    }
    for(i=0;i<=4;i++) {
        printf("data[%d]：%d\n",i,data[i]);
    }
    return 0;
}



    /*do {
        if(data[0]>data[1]) {
            temp = data[0];
            data[0] = data[1];
            data[1] = temp;
        }
        if(data[1]>data[2]) {
            temp = data[1];
            data[1] = data[2];
            data[2] = temp;
        }
        if(data[2]>data[3]) {
            temp = data[2];
            data[2] = data[3];
            data[3] = temp;
        }
        if(data[3]>data[4]) {
            temp = data[3];
            data[3] = data[4];
            data[4] = temp;
        }
        j++;
    }while(j < 100);
    
        if(dai<=data[i]) {
            dai = data[i];
        }
        if(sho==0){
            sho = data[i];
        }
        else if(sho>data[i]){
            sho = data[i];
        }
    }*/
