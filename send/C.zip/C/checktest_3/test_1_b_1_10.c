#include<stdio.h>

int main() {
    char len[]="ABCDEFGABABCFZZXYH";
    char serch, *p;
    int i,kai=0;
    int start=1;

    p = len;

    printf("検索する文字を入力してください：");
    scanf_s("%c", & serch);

    //検索部分
    while(*p!='\0') {
        if(*p==serch) {
            kai++;
            printf("%cの%d回目は、%d文字目です。\n",serch,kai,start);
        }
        p++;
        start++;
    }
    if(kai == 0) {
        printf("Not Found\n");
    }
    return 0;
}