/*ポインタ演習問題2*/

#include<stdio.h>

int main() {
    int i,j;
    char str[] = "hello world";
    j = sizeof str;
    *(str) = 'H';
    *(str + 6) = 'W';

    for(i=0;i<=j;i++) {
        printf("%c",str[i]);
    }
    return 0;
}