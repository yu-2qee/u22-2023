/*ポインタ演習 Webサイト*/

#include<stdio.h>

int doubleValue();

int main() {
    int a,b,*p;
    p = &a;

    printf("倍にする数値を入力：");
    scanf_s("%d", & a);
    b = doubleValue(*p);
    printf("倍にした数値：%d",b);
    return 0;
}

int doubleValue(int p) {
    p *= 2;
    return p;
}