/*ポインタ演習問題 web問題*/

#include<stdio.h>

int main() {
    char arr[100];
    char *c;

    printf("文字列を入力してください：");
    scanf_s("%s", & arr);
    c = arr + strlen(arr) - 1;

    printf("逆順：");
    while(c >= arr) {
        printf("%c",*c);
        c--;
    }
    return 0;
}