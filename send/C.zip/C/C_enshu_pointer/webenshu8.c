/*ポインタ演習問題 web演習*/

#include<stdio.h>
#include<stdlib.h>

int main() {

    int* arr;
    int size =5;
    arr=(int*)malloc(size * sizeof(int));//()内の計算は型のサイズ×要素数

    if(arr== NULL) {
        printf("メモリの割り当てに失敗しました。");
        return 1;
    }
    for(int i=0;i<size;i++) {
        arr[i] = i*10;
    }
    for(int i=0;i<size;i++) {
        printf("%d ",arr[i]);
    }
    printf("\n");
    free(arr);
    return 0;
}