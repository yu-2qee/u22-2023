/*ポインタ演習問題 Webサイト*/

#include<stdio.h>

int main() {
    int a, *p;

    p = &a;
    a = 10;
    
    printf("元の値：%d", a);
    *p = 20;
    printf("変更後の値：%d", *p);

    return 0;
}