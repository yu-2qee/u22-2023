#include<stdio.h>

int main() {
    int i[9];
    int x,y,dai=0,sho=0;

    while(1){
        scanf_s("%d", & x);
        if(x == -1) {
            break;
        }
        i[y] = x;
        if(sho == 0) {
            sho = i[y];
        }

        if(i[y] > dai) {
            dai = i[y];
        }
        if(i[y] < sho) {
            sho = i[y];
        }
        y++;
    }
    printf("最大値：%d", dai);
    printf("最小値：%d", sho);
    return 0;
}