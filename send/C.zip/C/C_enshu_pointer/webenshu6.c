/*ポインタ演習問題 Web問題*/

#include<stdio.h>

int main() {
    char arr[] = "ThankYou";
    char *p;
    p = arr + 7;

    for(int i=0;i<=7;i++) {
        printf("%c",*p);
        p--;
    }
    return 0;
}