/*ポインタ演習問題 Webサイト*/

#include<stdio.h>

int main() {
    int a, *p;

    p = &a;
    scanf_s("%d", & a);

    printf("%d",*p);
    return 0;
}