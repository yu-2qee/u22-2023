/*ポインタ演習問題 web問題*/

#include<stdio.h>

int add();

int main() {
    int a,b,result;

    printf("変更前の値aを入力：");
    scanf_s("%d",& a);
    printf("変更前の値bを入力：");
    scanf_s("%d",& b);

    result = add(&a,&b);
    printf("変更前の値aを入力：%d\n",a);
    printf("変更前の値bを入力：%d\n",b);
    printf("a + b の値：%d\n",result);
    return 0;

}

int add(int *a,int *b) {
    *a += 1;
    *b += 2;
    return *a + *b;
}