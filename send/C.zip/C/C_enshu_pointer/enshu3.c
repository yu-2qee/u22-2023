/*ポインタ演習問題3*/

#include<stdio.h>

int main() {

    int *a, *b, *c, *d, *e, *f, *g, *h, *i, *j;
    int x;
    int *add;

    printf("入力した順番と逆の順番で出力します。\n");
    printf("10個データを入力してください。\n");
    scanf_s("%d", & a);
    scanf_s("%d", & b);
    scanf_s("%d", & c);
    scanf_s("%d", & d);
    scanf_s("%d", & e);
    scanf_s("%d", & f);
    scanf_s("%d", & g);
    scanf_s("%d", & h);
    scanf_s("%d", & i);
    scanf_s("%d", & j);

    add = &j;
    printf("%p", add);

    printf("逆の順番\n");
    for(int p=9;p=0;p--) {
        if(add == &a) {
            printf("%d ", a);
            add += 4;
        }
        if(add == &b) {
            printf("%d ", b);
            add += 4;
        }
        if(add == &c) {
            printf("%d ", c);
            add += 4;
        }
        if(add == &d) {
            printf("%d ", d);
            add += 4;
        }
        if(add == &e) {
            printf("%d ", e);
            add += 4;
        }if(add == &f) {
            printf("%d ", f);
            add += 4;
        }
        if(add == &g) {
            printf("%d ", g);
            add += 4;
        }
        if(add == &h) {
            printf("%d ", h);
            add += 4;
        }
        if(add == &i) {
            printf("%d ", i);
            add += 4;
        }
        if(add == &j) {
            printf("%d ", j);
            add += 4;
        }
    }
    return 0;

}