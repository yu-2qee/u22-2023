#include<stdio.h>

int main() {
    int num=10;
    int *p;

    p = &num;

    printf("numの値は： %d\n",*p);
    *p = 20;
    printf("numの値を変更しました。\n");
    printf("numの値は： %d\n",*p);
    printf("numのアドレスは%p\n",p);
    return 0;
}