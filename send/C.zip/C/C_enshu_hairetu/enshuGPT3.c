#include<stdio.h>

int main() {
    int arr[5];
    int i,sum=0;
    double ave;

    printf("整数を5つ入力してください。\n");
    for(i=0;i<5;i++){
        scanf_s("%d",& arr[i]);
        sum += arr[i];
    }
    ave = sum / 5.0;
    printf("合計値：%d\n",sum);
    printf("平均値：%.2f\n",ave);
    return 0;
}