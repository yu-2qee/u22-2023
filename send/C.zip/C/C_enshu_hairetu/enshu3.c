/*配列演習問題3*/

#include<stdio.h>

int main() {

    int a[9];
    int b[9];
    int i, amari;
    int count=0;
    printf("入力した10個の数値を奇数偶数に分けて表示します。\n");
    printf("数値を10個入力してください。\n");
    for(i=0; i<=9; i++) {
        scanf_s("%d", & a[i]);
    }
    printf("偶数：");

    //偶数の表示
    for(i=0; i<=9; i++) {
        amari = a[i] % 2;
        if(amari == 0) {
            printf("%d ", a[i]);
        }
    }
    printf("\n奇数：");

    //奇数の表示
    for(i=0; i<=9; i++) {
        amari = a[i] % 2;
        if(amari == 1) {
            printf("%d ", a[i]);
        }
    }
}