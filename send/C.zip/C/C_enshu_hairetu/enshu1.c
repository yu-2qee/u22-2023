/*配列演習問題1*/

#include<stdio.h>

int main() {
    int a[10];
    int i, j;
    printf("入力した10個の数値を二倍にして表示します。\n");
    printf("数値を10個入力してください。\n");
    for( i=0; i<=9; i++){
        scanf_s("%d", & a[i]);
    }
    printf("二倍にして表示します。\n");
        for( i=0; i<=9; i++) {
        j = a[i] * 2 ;
        printf("%d ", j);
    }
    return 0;
}