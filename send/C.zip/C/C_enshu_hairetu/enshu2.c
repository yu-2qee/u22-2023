/*配列演習問題2*/

#include<stdio.h>

int main() {
    int a[9];
    int i, j, k;
    printf("入力した10個の数値を入力順と逆にして表示します。\n");
    printf("数値を10個入力してください。\n");
    for(i=0; i<=9; i++){
        scanf_s("%d", & a[i]);
    }

    /*for(int t = 0; t<=9; t++) {
        printf("%d \n", a[t]);
    }*/

    printf("逆順で表示します。\n");
    for(j=9; j>=0; j--) {
        printf("%d \n", a[j]);
    }
    return 0;
}