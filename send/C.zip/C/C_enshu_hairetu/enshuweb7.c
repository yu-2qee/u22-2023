#include<stdio.h>

int main() {
    int arr[] = {5,10,15,20};
    int *p = arr;
    int i;

    for(i=0;i<=3;i++) {
        printf("%d番目の要素： %d\n",i,*(p + i));
    }
    return 0;
}