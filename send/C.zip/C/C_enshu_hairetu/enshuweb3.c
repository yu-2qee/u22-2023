#include<stdio.h>

int main() {
    int i, n;
    double data[100];

    printf("数字を入力してください：");
    printf("入力を終えるときにはCtr-dを押してください。\n");

    n = 0;
    while(scanf_s("%d",&data[n]) != EOF) {
        n++;
    }
    for(i=0;i<n;i++) {
        printf("data[%d] =%d\n",i,data[i]);
    }
    return 0;
}