#include<stdio.h>

int main() {
    int arr[5];
    int i;

    printf("整数を5つ入力してください。\n");
    for(i=0;i<5;i++){
        scanf_s("%d",& arr[i]);
    }
    for(i=0;i<5;i++){
        printf("%d ",arr[i]);
    }
    return 0;
}