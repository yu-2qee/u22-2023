#include<stdio.h>
#define N 11

int main() {
    int i,n,data,num[n];

    for(i=0;i<N;i++) {
        num[i] = 0;
    }

    printf("テストの点数を入力してください。\n");
    printf("入力を終えるときは-1を入力してください。\n");

    n=0;
    while(1){
        if(data < 0 || data > 100) {
            printf("入力された数値は0から100までの数字ではありません。\n");
            if(data == -1) {
                printf("入力された値が-1だったため終了します。\n");
                break;
            }
        }
        else {
            num[data/10]++;
            n++;
        }
    }

    for(i=0;i<N;i++) {
        printf("%3d点以上%3d点未満 = %3d人\n",i*10,(i+1)*10,num[i]);
    }
    printf("100点               %3d人\n",num[N-1]);

    printf("--------------------------------\n");
    printf("合計                 %3d", n);
    return 0;
}