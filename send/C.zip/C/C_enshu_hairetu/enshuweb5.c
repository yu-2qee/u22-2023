#include <stdio.h>
#define  N  5

int main(void) {

    int i, j;
    int mat[N][N]={
          {2,0,2,0,0},{0,1,0,0,0},{3,0,6,0,0},{0,4,0,1,0},{0,0,0,7,1}};

    for (i=0; i<N; i++) {
        for (j=0; j<N; j++) {
            printf("%3d", mat[i][j]);
        }
        printf("\n");
    }
    return (0);
}