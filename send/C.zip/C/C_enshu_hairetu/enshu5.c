/*配列演習問題5*/

#include<stdio.h>

int main() {

    int binary[16];
    int value;
    int i;
    scanf_s("%d", & value);

    i = 0;


    while(value > 0) {
        binary[i] = value % 2;
        value = value /2;
        i++;
    }

    /*for(i=0; i<=15; i++) {
        printf("%d", binary[i]);
    }*/

    for (int j = i - 1; j >= 0; j--) {
        printf("%d", binary[j]);
    }
    return 0;
}