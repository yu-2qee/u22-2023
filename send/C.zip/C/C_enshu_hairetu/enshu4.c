/*配列演習問題4*/

#include<stdio.h>

int main() {
    int i, j, gou;
    int x[10];

    printf("数値を入力してください。(数値の合計が100を超えるか、数値の個数が10個になった時終了します)\n");

    for(j=0;j<=9;j++) {
        scanf_s("%d", & i);
        x[j] = i;
        gou += i;
        if(gou >= 100){
            break;
        }
    }
    for(i=0;i<=j;i++) {
        printf("%d ",x[i]);
    }
    return 0;
}