#include<stdio.h>

int main() {
    char a;

    printf("文字を一文字入れてください---");
    scanf_s("%c", & a);
    printf("変換します---");
    a = a + 32;
    printf("%c", a);

    return 0;
}