#include<stdio.h>

int main() {
    char a = a;
    int x,i,y;
    printf("列の数を入力してください---");
    scanf_s("%d",x);

    for(y=1;y<=x;y++) {
        for(i=1; i<=26; i++) {
            printf("%c",a);
            a += i;
        }
        printf("\n");
    }

}