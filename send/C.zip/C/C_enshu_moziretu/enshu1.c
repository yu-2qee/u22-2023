/*文字列演習問題1*/

#include<stdio.h>

int main() {
    char *a, *b, *c;

    scanf_s("%s", & a);
    scanf_s("%s", & b);
    scanf_s("%s", & c);
    
    printf("”");
    printf("%c",a);
    printf("%c",b);
    printf("%c",c);
    printf("”");

    return 0;
}