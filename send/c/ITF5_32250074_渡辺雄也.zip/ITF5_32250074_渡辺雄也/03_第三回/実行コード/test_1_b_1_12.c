// #include <stdio.h>
 
//  int main() {
//      char mozi[100] = "MEITEC   ";
//      char ikkome;
 
//      for (int i = 0; i < 9 + 1; i++) {
//          printf("\r%s", mozi);
 
//          ikkome = mozi[0];
//          for (int i = 0; i < 9 - 1; i++) {
//              mozi[i] = mozi[i + 1];
//          }
 
//          mozi[9 - 1] = ikkome;
 
//          for(int i = 0; i < 900000000; i++){}
       
//      }
 
//      return 0;
//  }



// #include <stdio.h>
 
//  int main() {
//      char mozi[100] = "MEITEC   ";
//      char ikkome;
 
//      for (int i = 0; i < 90000 + 1; i++) {
//          printf("\r%s", mozi);
 
//          ikkome = mozi[0];
//          for (int i = 0; i < 9 - 1; i++) {
//              mozi[i] = mozi[i + 1];
//          }
 
//          mozi[9 - 1] = ikkome;
 
//          for(int i = 0; i < 9000000000; i++){}
       
//      }
 
//      return 0;
//  }

#include <stdio.h>

int main() {
    char moji[] = "MEITEC   ", ikkome;
    for (int i = 0; i < 90001; i++) {
        printf("\r%s", moji);
        for (int j = 0; j < 9e8; j++);
        ikkome = moji[0];
        for (int j = 0; j < 8; j++) moji[j] = moji[j + 1];
        moji[8] = ikkome;
    }
}
