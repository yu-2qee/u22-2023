#include <stdio.h>
int main(void)
{
    int data[5];
    int i = 0;
    int j = 0;
    int temp = 0;
    while (i < 5)
    {
        printf("data[%d]:", i);
        int input;
        int result = scanf_s("%d", &input);
        if (result == 1)
        {
            data[i] = input;
            i = i + 1;
        }
        else
       {
    printf("正しい数値を入力してください。\n");
    while (getchar() != '\n');
    }
    }i = 0;
    while (i < 5)
    {
        j = 1;
        while (j < (5 - i))
        {
            int left = data[j - 1];
            int right = data[j];
            if (right < left)
            {
                temp = data[j];
                data[j] = data[j - 1];
                data[j - 1] = temp;
            }
            j = j + 1;
        }        
        i = i + 1;
    }
    i = 0;
    for (; i < 5;){
        printf("data[%d]:%d\n", i, data[i]);
        i = i + 1;
    }
    return 0;
}
