#include <stdio.h>

int main(void) {
    int i, min;
    int sum = 0;
    int num[5] = {0};

    printf("値を入力してください。\n");
    for(i = 0; i < 5; i++) {
        printf("%d番:",i + 1);
        scanf_s("%d", &num[i]);
        sum = sum + num[i];
        if(i == 0) {
            min = num[i];
        } else {
            if(min > num[i]) {
                min = num[i];
            }
        }
    }
    printf("合計値：%d\n", sum);
    printf("最小値：%d\n", min);
    printf("平均値：%5.1f\n", (double)sum / 5);
    return 0;
}
