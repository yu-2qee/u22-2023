#include <stdio.h>
int main(void){
    char str[] = "ABCDEFGABABCFZZXYH";
    char ch;
    int count = 0;
    int position = 0;
    printf("検索する文字を1文字入力してください: ");
    scanf_s(" %c", &ch);
    while(str[position] != '\0'){
        if(str[position] == ch){
            count++;
            printf("%d文字目で %d回目の出現です。\n", position + 1, count);
        }
        position++;
    }
    if(count == 0) printf("Not Found\n");
    return 0;
}
