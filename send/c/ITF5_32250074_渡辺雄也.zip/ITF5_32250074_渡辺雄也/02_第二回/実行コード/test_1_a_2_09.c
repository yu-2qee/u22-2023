#include <stdio.h>
#include <stdlib.h>  
#include <time.h>   
int main(void)
{
    int no; 
    int pin; 
    int i;

  srand(time(NULL));

    no = rand() % 100 + 1;
    pin = 0;

    printf("数字が決まりました！\n");

    for (i = 0; i < 10 && pin != no; i++) {
        printf("考えた数字を入力してください: ");
        scanf_s("%d", &pin);

        if (pin == no) {
            printf("正解!\n");
            printf("%d はあたりです!!!\n", no);
            break;
        } else {
            printf("残念、違います。\n");
            if (pin > no)
                printf("もっと小さい数字です。\n");  
            else
                printf("もっと大きい数字です。\n");  
        }
    }

    if (pin != no) {
        printf("残念.........終了します。\n");
    }

    return 0;
}
