#include <stdio.h>

int i , j, prime; 
int main(void) 
{ 
do { 
printf("正の整数を入力してください："); 
scanf_s("%d", &i); 
prime = 1; 
for (j = 2; j <= i / 2; j++) 
if (!(i % j)) 
prime = 0; 
if (prime) 
printf("%d は素数です\n", i); 
else 
printf("%d は素数ではありません\n", i); 
} while (i); 
return 0;
}