// #include <stdio.h>

// int fact(int i);
// int main(void){
//     int x;
//     printf("数を13以下で入力してください：");
//     scanf_s("%d", &x);  
//     printf("入力された階乗は %d です\n", fact(x));
//     return 0;
// }

// int fact(int i){
//     if (i <= 1)  
//         return 1;
//     else
//         return i*fact(i - 1);
//         }


#include <stdio.h>

int fact(int i);

int main(void) {
    int x;
    printf("数を13以下で入力してください：");
    scanf_s("%d", &x);  
    printf("入力された階乗は %d です\n", fact(x));
    return 0;
}

int fact(int i) {
    int result = 1;
    for (int j = 2; j <= i; j++) {
        result *= j;
    }
    return result;
}
