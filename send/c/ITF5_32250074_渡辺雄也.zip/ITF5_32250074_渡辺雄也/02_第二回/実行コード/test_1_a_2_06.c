#include <stdio.h> 
int main(void) 
{ 
int room, len, width, sum; 
int i=0;

printf("部屋の数を入力してください："); 
scanf_s("%d", &room); 
sum = 0; 
for (i= room ;i >0 ;i--) { 
printf("\n 長さを入力してください："); 
scanf_s("%d",&len); 
printf("幅を入力してください："); 
scanf_s("%d",&width); 
sum = sum + len* width;}

printf("総床面積：%d",sum); 
return 0; 
} 