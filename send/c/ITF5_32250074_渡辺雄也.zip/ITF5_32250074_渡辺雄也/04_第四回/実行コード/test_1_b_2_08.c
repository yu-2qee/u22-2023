#include <stdio.h>

int main() {
    char name[100];
    int month, day, year;
    char phone[20];


    printf("名前を入力してください: ");
    scanf_s("%99s", name); 

    printf("生年月日を mm/dd/yy の形式で入力してください: ");
    scanf_s("%d/%d/%d", &month, &day, &year);

    printf("電話番号を入力してください: ");
    scanf_s("%19s", phone);  

    printf("\n--- 入力された情報 ---\n");
    printf("名前: %s\n", name);
    printf("生年月日: %02d/%02d/%02d\n", month, day, year);
    printf("電話番号: %s\n", phone);

    return 0;
}
