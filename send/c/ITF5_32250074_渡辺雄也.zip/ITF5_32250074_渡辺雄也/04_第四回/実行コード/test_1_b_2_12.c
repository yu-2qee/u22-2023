#include <stdio.h>

int main() {
    int n, score;
    int excellent = 0, good = 0, miss = 0, missx = 0;

    do {
        printf("評価する人数を入力（最大100人）：");
        scanf_s("%d", &n);
    } while (n <= 0 || n > 100);
    for (int i = 0; i < n; i++) {
        do {
            printf("%d人目 得点：", i + 1);
            scanf_s("%d", &score);
        } while (score < 0 || score > 100);

        if (score >= 90)
            excellent++;
        else if (score >= 70)
            good++;
        else if (score >= 50)
            miss++;
        else
            missx++;
    }
    printf("\n--- 評価結果 ---\n");
    printf("優 %d 人\n良 %d 人\n可 %d 人\n不可 %d 人\n", excellent, good, miss, missx);

    return 0;
}
