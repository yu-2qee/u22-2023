#include <stdio.h>

int main() {
    int data[3][5] = {
        {1, 2, 3, 4, 5},
        {6, 7, 8, 9, 10},
        {99, 98, 97, 96, 95}
    };
    int sum = 0;
    int *p = &data[0][0];  
    for (int i = 0; i < 15; i++) {
        sum += *(p + i);  
    }
    printf("配列の全要素の合計: %d\n", sum);

    return 0;
}
