#include <stdio.h>
void mygets(char *str) {
    int i = 0;
    char ch;

    while (1) {
        ch = getchar();        
        if (ch == '\n') break; 
        str[i++] = ch;         
    }
    str[i] = '\0';             
}
int main() {
    char buffer[100];
    printf("文字列を入力してください：");
    mygets(buffer);  
    printf("入力された文字列：%s\n", buffer);  

    return 0;
}